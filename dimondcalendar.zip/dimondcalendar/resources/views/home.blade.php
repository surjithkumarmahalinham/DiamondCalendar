@extends('layouts.app')

@section('content')
@if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<section class="py-5 mb-5">
    <div class="container">
        <div id="calendar"></div>
        
    </div>
</section>
<script>
$(document).ready(function() {

$('#calendar').fullCalendar({
    header:{
            left:'prev,next today',
            center:'title',
            right:'month,agendaWeek,agendaDay'
        }
    });

});
getevent();
function getevent()
{
    $.ajax({
        type : 'GET',
        url : '{{ route("getevent") }}',
        dataType : 'json',
        success: function (result) {
            
        var newEvents = result.eventdata;

        $('#calendar').fullCalendar('addEventSource',(newEvents));
        $('#calendar').fullCalendar('render'); 
        },
        error: function (e) {
            console.log(e);
        }
    }); 
}
</script>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://momentjs.com/downloads/moment.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.js'></script>
<link rel='stylesheet' href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css"/>